
from web3 import Web3
from solcx import compile_standard, install_solc

w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:7545"))
w3.eth.default_account = w3.eth.accounts[0]

install_solc("0.8.0")
with open("contract.sol", "r") as file:
    contract_source_code = file.read()

compiled_sol = compile_standard(
    {"language": "Solidity",
     "sources": {"contract.sol": {"content": contract_source_code}},
     "settings": {"outputSelection": {"*": {"*": ["abi", "evm.bytecode"]}}}},
    solc_version="0.8.0",
)

bytecode = compiled_sol["contracts"]["contract.sol"]["TransactionContract"]["evm"]["bytecode"]["object"]
abi = compiled_sol["contracts"]["contract.sol"]["TransactionContract"]["abi"]

contract = w3.eth.contract(abi=abi, bytecode=bytecode)
tx_hash = contract.constructor().transact()
tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)

print(f"Contract deployed at: {tx_receipt.contractAddress}")
