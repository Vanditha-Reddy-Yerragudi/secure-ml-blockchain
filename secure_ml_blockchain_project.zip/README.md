# Secure ML-Powered Financial Transactions

This project includes:
- Fraud detection using ML
- Blockchain-based logging
- Flask-based API