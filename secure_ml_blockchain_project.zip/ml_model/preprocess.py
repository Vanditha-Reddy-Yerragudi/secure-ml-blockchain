
import pandas as pd
from sklearn.model_selection import train_test_split

def load_and_preprocess(file_path):
    df = pd.read_csv(file_path)
    df.fillna(0, inplace=True)
    df = pd.get_dummies(df, columns=['transaction_type'])
    X = df.drop(['is_fraud'], axis=1)
    y = df['is_fraud']
    return train_test_split(X, y, test_size=0.2, random_state=42)
