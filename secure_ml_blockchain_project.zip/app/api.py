
from flask import Flask, request, jsonify
from web3 import Web3
import numpy as np

app = Flask(__name__)

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    prediction = 0 if data['amount'] < 3000 else 1

    return jsonify({"fraud": bool(prediction)})

if __name__ == "__main__":
    app.run(debug=True)
